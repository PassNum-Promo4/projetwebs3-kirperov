module.exports = {
    database:
     'mongodb://kirill:589750S@ds235850.mlab.com:35850/sportkirillapp',
    port: 3030,
    secret: "KirillPetrov2012312321"
};